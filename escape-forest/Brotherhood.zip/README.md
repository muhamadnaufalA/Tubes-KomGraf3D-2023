# Escape-from-Monkey
Awas ada iman.

![Alt Text](https://media.giphy.com/media/pgkqWggvUUd7e3iprE/giphy.gif)
